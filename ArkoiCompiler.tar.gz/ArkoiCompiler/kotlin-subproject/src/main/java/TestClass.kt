/*
 * Copyright © 2019-2020 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on April 07, 2020
 * Author timo aka. єхcsє#5543
 */

class TestClass {
	
	fun haha(helloWorld: HelloWorld) {
		println(helloWorld.hello)
	}
	
}