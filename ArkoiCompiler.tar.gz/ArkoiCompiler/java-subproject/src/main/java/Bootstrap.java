/*
 * Copyright © 2019-2020 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on April 07, 2020
 * Author timo aka. єхcsє#5543
 */

public class Bootstrap
{
    
    public static void main(String[] args) {
        final TestClass testClass = new TestClass();
        testClass.haha(new HelloWorld("s"));
    }
    
}
