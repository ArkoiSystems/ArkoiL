/*
 * Copyright © 2019-2020 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on April 07, 2020
 * Author timo aka. єхcsє#5543
 */

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public class HelloWorld
{
    
    @Getter
    private final String hello;
    
}
