package com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.types;

import com.arkoisystems.arkoicompiler.stage.errorHandler.types.doubles.DoubleSyntaxASTError;
import com.arkoisystems.arkoicompiler.stage.lexcialAnalyzer.token.types.IdentifierToken;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.SemanticAnalyzer;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.AbstractSemanticAST;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.types.statements.FunctionDefinitionSemanticAST;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.types.statements.ImportDefinitionSemanticAST;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.types.statements.VariableDefinitionSemanticAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.ASTType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.RootSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.statement.types.FunctionDefinitionSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.statement.types.ImportDefinitionSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.statement.types.VariableDefinitionSyntaxAST;
import com.google.gson.annotations.Expose;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * Copyright © 2019 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on the Sat Nov 09 2019 Author єхcsє#5543 aka timo
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * <p>
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
@Getter
@Setter
public class RootSemanticAST extends AbstractSemanticAST<RootSyntaxAST>
{
    
    @Expose
    private final List<ImportDefinitionSemanticAST> importStorage;
    
    @Expose
    private final List<VariableDefinitionSemanticAST> variableStorage;
    
    @Expose
    private final List<FunctionDefinitionSemanticAST> functionStorage;
    
    public RootSemanticAST(final RootSyntaxAST rootSyntaxAST) {
        super(null, rootSyntaxAST, ASTType.ROOT);
    
        this.variableStorage = new ArrayList<>();
        this.functionStorage = new ArrayList<>();
        this.importStorage = new ArrayList<>();
    }
    
    @Override
    public RootSemanticAST analyseAST(final SemanticAnalyzer semanticAnalyzer) {
        final List<AbstractSemanticAST<?>> abstractSemanticASTS = new ArrayList<>();
        abstractSemanticASTS.addAll(this.getImportStorage());
        abstractSemanticASTS.addAll(this.getVariableStorage());
        abstractSemanticASTS.sort(Comparator.comparingInt(AbstractSemanticAST::getStart));
        
        final HashMap<String, AbstractSemanticAST<?>> names = new HashMap<>();
        for (final AbstractSemanticAST<?> abstractSemanticAST : abstractSemanticASTS) {
            final String name = this.getName(abstractSemanticAST);
            if (name == null)
                continue;
            
            if (!names.containsKey(name)) {
                names.put(name, abstractSemanticAST);
                
                if (abstractSemanticAST.analyseAST(semanticAnalyzer) == null)
                    return null;
            } else {
                semanticAnalyzer.errorHandler().addError(new DoubleSyntaxASTError<>(names.get(name).getSyntaxAST(), abstractSemanticAST.getSyntaxAST(), "Couldn't analyse the semantic of this AST because it already exists with this name."));
                return null;
            }
        }
        
        final HashMap<String, FunctionDefinitionSemanticAST> functionDescriptions = new HashMap<>();
        for (final FunctionDefinitionSemanticAST functionDefinitionSemanticAST : this.getFunctionStorage()) {
            final String functionDescription = this.getFunctionDescription(functionDefinitionSemanticAST);
            
            if (!functionDescriptions.containsKey(functionDescription)) {
                functionDescriptions.put(functionDescription, functionDefinitionSemanticAST);
                
                if (functionDefinitionSemanticAST.analyseAST(semanticAnalyzer) == null)
                    return null;
            } else {
                semanticAnalyzer.errorHandler().addError(new DoubleSyntaxASTError<>(functionDescriptions.get(functionDescription).getSyntaxAST(), functionDefinitionSemanticAST.getSyntaxAST(), "Couldn't analyse the semantic of this function because there already exists a function with this description."));
                return null;
            }
        }
        
        return this;
    }
    
    @Override
    public boolean initialize(final SemanticAnalyzer semanticAnalyzer) {
        for (final ImportDefinitionSyntaxAST importDefinitionSyntaxAST : this.getSyntaxAST().getImportStorage()) {
            final ImportDefinitionSemanticAST importDefinitionSemanticAST = new ImportDefinitionSemanticAST(this, importDefinitionSyntaxAST);
            importDefinitionSemanticAST.initialize(semanticAnalyzer);
            this.importStorage.add(importDefinitionSemanticAST);
        }
        for (final VariableDefinitionSyntaxAST variableDefinitionSyntaxAST : this.getSyntaxAST().getVariableStorage()) {
            final VariableDefinitionSemanticAST variableDefinitionSemanticAST = new VariableDefinitionSemanticAST(this, variableDefinitionSyntaxAST);
            variableDefinitionSemanticAST.initialize(semanticAnalyzer);
            this.variableStorage.add(variableDefinitionSemanticAST);
        }
        for (final FunctionDefinitionSyntaxAST functionDefinitionSyntaxAST : this.getSyntaxAST().getFunctionStorage()) {
            final FunctionDefinitionSemanticAST functionDefinitionSemanticAST = new FunctionDefinitionSemanticAST(this, functionDefinitionSyntaxAST);
            functionDefinitionSemanticAST.initialize(semanticAnalyzer);
            this.functionStorage.add(functionDefinitionSemanticAST);
        }
        return true;
    }
    
    public String getFunctionDescription(final FunctionDefinitionSemanticAST functionDefinitionSemanticAST) {
        StringBuilder functionDescription = new StringBuilder(functionDefinitionSemanticAST.getFunctionName().getTokenContent());
        for (final ArgumentDefinitionSemanticAST argumentDefinitionSemanticAST : functionDefinitionSemanticAST.getFunctionArguments())
            functionDescription.append(argumentDefinitionSemanticAST.getArgumentType().getTypeKind().getName());
        return functionDescription.toString().intern();
    }
    
    private String getName(final AbstractSemanticAST<?> abstractSemanticAST) {
        if (abstractSemanticAST instanceof ImportDefinitionSemanticAST)
            return ((ImportDefinitionSemanticAST) abstractSemanticAST).getImportName().getTokenContent();
        else if (abstractSemanticAST instanceof VariableDefinitionSemanticAST)
            return ((VariableDefinitionSemanticAST) abstractSemanticAST).getVariableName().getTokenContent();
        return null;
    }
    
    public AbstractSemanticAST<?> findSemanticAST(final IdentifierToken nameToken) {
        for (final ImportDefinitionSemanticAST importDefinitionSemanticAST : this.getImportStorage()) {
            if (importDefinitionSemanticAST.getImportName().getTokenContent().equals(nameToken.getTokenContent()))
                return importDefinitionSemanticAST;
        }
        for (final VariableDefinitionSemanticAST variableDefinitionSemanticAST : this.getVariableStorage()) {
            if (variableDefinitionSemanticAST.getVariableName().getTokenContent().equals(nameToken.getTokenContent()))
                return variableDefinitionSemanticAST;
        }
        return null;
    }
    
    public FunctionDefinitionSemanticAST findFunction(final String functionDescription) {
        for (final FunctionDefinitionSemanticAST functionDefinitionSemanticAST : this.getFunctionStorage()) {
            if (this.getFunctionDescription(functionDefinitionSemanticAST).equals(functionDescription))
                return functionDefinitionSemanticAST;
        }
        return null;
    }
    
}
