package com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.types.statements;

import com.arkoisystems.arkoicompiler.stage.lexcialAnalyzer.token.types.IdentifierToken;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.SemanticAnalyzer;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.AbstractSemanticAST;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.types.AnnotationSemanticAST;
import com.arkoisystems.arkoicompiler.stage.semanticAnalyzer.ast.types.operable.types.expression.types.ExpressionSemanticAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.ASTType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.AnnotationSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.statement.types.VariableDefinitionSyntaxAST;
import com.google.gson.annotations.Expose;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Copyright © 2019 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on the Sat Nov 09 2019 Author єхcsє#5543 aka timo
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * <p>
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
@Getter
@Setter
public class VariableDefinitionSemanticAST extends AbstractSemanticAST<VariableDefinitionSyntaxAST>
{
    
    @Expose
    private final List<AnnotationSemanticAST> variableAnnotations;
    
    @Expose
    private IdentifierToken variableName;
    
    @Expose
    private ExpressionSemanticAST variableExpression;
    
    public VariableDefinitionSemanticAST(final AbstractSemanticAST<?> lastContainerAST, final VariableDefinitionSyntaxAST variableDefinitionSyntaxAST) {
        super(lastContainerAST, variableDefinitionSyntaxAST, ASTType.VARIABLE_DEFINITION);
        
        this.variableAnnotations = new ArrayList<>();
    }
    
    @Override
    public VariableDefinitionSemanticAST analyseAST(final SemanticAnalyzer semanticAnalyzer) {
        for(final AnnotationSyntaxAST annotationSyntaxAST : this.getSyntaxAST().getVariableAnnotations()) {
            final AnnotationSemanticAST annotationSemanticAST
                    = new AnnotationSemanticAST(this.getLastContainerAST(), annotationSyntaxAST).analyseAST(semanticAnalyzer);
            if(annotationSemanticAST == null)
                return null;
            
            this.variableAnnotations.add(annotationSemanticAST);
        }
        
        final ExpressionSemanticAST expressionSemanticAST
                = new ExpressionSemanticAST(this.getLastContainerAST(), this.getSyntaxAST().getExpressionAST()).analyseAST(semanticAnalyzer);
        if(expressionSemanticAST == null)
            return null;
        
        this.variableExpression = expressionSemanticAST;
        return this;
    }
    
    @Override
    public boolean initialize(final SemanticAnalyzer semanticAnalyzer) {
        this.variableName = this.getSyntaxAST().getVariableNameToken();
        return true;
    }
    
}
