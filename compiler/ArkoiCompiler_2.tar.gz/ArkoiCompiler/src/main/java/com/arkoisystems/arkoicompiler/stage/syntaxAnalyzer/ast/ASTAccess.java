package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast;

public enum ASTAccess
{
    
    THIS_ACCESS,
    GLOBAL_ACCESS,
    
}