plugins {
    java
}

group = "com.arkoisystems"
version = "2.0.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testCompile("junit", "junit", "4.12")
    
    annotationProcessor("org.projectlombok", "lombok", "1.18.8")
    compileOnly("org.projectlombok", "lombok", "1.18.8")
    
    compile("commons-cli", "commons-cli", "1.4")
}

configure<JavaPluginConvention> {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}