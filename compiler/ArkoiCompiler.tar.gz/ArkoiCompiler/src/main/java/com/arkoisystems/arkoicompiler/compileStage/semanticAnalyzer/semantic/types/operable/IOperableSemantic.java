package com.arkoisystems.arkoicompiler.compileStage.semanticAnalyzer.semantic.types.operable;

import com.arkoisystems.arkoicompiler.compileStage.semanticAnalyzer.SemanticAnalyzer;
import com.arkoisystems.arkoicompiler.compileStage.syntaxAnalyzer.ast.AbstractAST;

/**
 * Copyright © 2019 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on the Sat Nov 09 2019 Author єхcsє#5543 aka timo
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * <p>
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
public interface IOperableSemantic
{
    
    /*
        BinaryExpressionAST
     */
    boolean binAdd(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean binSub(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean binMul(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean binDiv(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean binMod(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    /*
        AssignmentExpressionAST
     */
    boolean assign(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean addAssign(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean subAssign(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean mulAssign(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean divAssign(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean modAssign(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    /*
        EqualityExpressionAST
     */
    boolean equal(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean notEqual(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    /*
        LogicalExpressionAST
     */
    boolean logicalOr(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean logicalAnd(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    /*
        PostfixExpressionAST
     */
    boolean postfixAdd(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> abstractAST);
    
    boolean postfixSub(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> abstractAST);
    
    /*
        PrefixExpressionAST
     */
    boolean prefixAdd(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> abstractAST);
    
    boolean prefixSub(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> abstractAST);
    
    boolean prefixNegate(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> abstractAST);
    
    boolean prefixAffirm(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> abstractAST);
    
    /*
        PrefixExpressionAST
     */
    boolean relationalLessThan(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean relationalGreaterThan(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean relationalLessEqualThan(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean relationalGreaterEqualThan(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
    boolean relationalIs(final SemanticAnalyzer semanticAnalyzer, final AbstractAST<?> leftSideAST, final AbstractAST<?> rightSideAST);
    
}
