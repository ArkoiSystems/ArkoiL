package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.utils;

public enum FunctionInvocation
{
    
    BLOCK_INVOCATION,
    EXPRESSION_INVOCATION
    
}