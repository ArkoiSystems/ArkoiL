package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.operators;

public enum CastOperatorType
{
    
    BYTE,
    FLOAT,
    SHORT,
    DOUBLE,
    INTEGER
    
}