/*
 * Copyright © 2019-2020 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on February 15, 2020
 * Author timo aka. єхcsє#5543
 */
package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.types;

import com.arkoisystems.arkoicompiler.stage.lexcialAnalyzer.token.types.IdentifierToken;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.SyntaxAnalyzer;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.AbstractSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.AbstractOperableSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.AbstractExpressionSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.operators.CastOperatorType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.utils.ASTType;
import lombok.Getter;
import lombok.Setter;

import java.io.PrintStream;

import static com.arkoisystems.arkoicompiler.stage.lexcialAnalyzer.token.utils.TokenType.IDENTIFIER;

public class CastExpressionSyntaxAST extends AbstractExpressionSyntaxAST
{
    
    
    @Getter
    @Setter
    private CastOperatorType castOperatorType;
    
    
    @Getter
    @Setter
    private AbstractOperableSyntaxAST<?> leftSideOperable;
    
    
    public CastExpressionSyntaxAST(final SyntaxAnalyzer syntaxAnalyzer) {
        super(syntaxAnalyzer, ASTType.CAST_EXPRESSION);
    }
    
    
    @Override
    public AbstractOperableSyntaxAST<?> parseAST(final AbstractSyntaxAST parentAST) {
        AbstractOperableSyntaxAST<?> leftSideAST = new ParenthesizedExpressionSyntaxAST(this.getSyntaxAnalyzer()).parseAST(this);
        if (leftSideAST == null)
            return null;
        
        if (this.getSyntaxAnalyzer().matchesPeekToken(1, IDENTIFIER) != null) {
            final IdentifierToken identifierToken = (IdentifierToken) this.getSyntaxAnalyzer().nextToken(1);
            switch (identifierToken.getTokenContent()) {
                case "f":
                case "F":
                    this.castOperatorType = CastOperatorType.FLOAT;
                    break;
                case "d":
                case "D":
                    this.castOperatorType = CastOperatorType.DOUBLE;
                    break;
                case "s":
                case "S":
                    this.castOperatorType = CastOperatorType.SHORT;
                    break;
                case "i":
                case "I":
                    this.castOperatorType = CastOperatorType.INTEGER;
                    break;
                case "b":
                case "B":
                    this.castOperatorType = CastOperatorType.BYTE;
                    break;
                default:
                    this.addError(
                            this.getSyntaxAnalyzer().getArkoiClass(),
                            identifierToken,
                            "Couldn't parse the cast expression because it contains an unsupported cast \"%s\".",
                            identifierToken.getTokenContent()
                    );
                    return null;
            }
            
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd(identifierToken.getEnd());
            leftSideAST = this;
        }
        return leftSideAST;
    }
    
    
    @Override
    public void printSyntaxAST(final PrintStream printStream, final String indents) {
        printStream.println(indents + "├── left:");
        printStream.println(indents + "│   └── " + this.getLeftSideOperable().getClass().getSimpleName());
        this.getLeftSideOperable().printSyntaxAST(printStream, indents + "│       ");
        printStream.println(indents + "└── operator: " + this.getCastOperatorType());
    }
    
}
