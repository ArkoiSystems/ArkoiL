/*
 * Copyright © 2019-2020 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on February 15, 2020
 * Author timo aka. єхcsє#5543
 */
package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.types;

import com.arkoisystems.arkoicompiler.stage.lexcialAnalyzer.token.types.SymbolToken;
import com.arkoisystems.arkoicompiler.stage.lexcialAnalyzer.token.utils.SymbolType;
import com.arkoisystems.arkoicompiler.stage.lexcialAnalyzer.token.utils.TokenType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.SyntaxAnalyzer;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.SyntaxErrorType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.AbstractSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.AbstractOperableSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.AbstractExpressionSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.operators.AssignmentOperatorType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.operators.BinaryOperatorType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.operators.LogicalOperatorType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.utils.ASTType;
import lombok.Getter;
import lombok.Setter;

import java.io.PrintStream;

public class AssignmentExpressionSyntaxAST extends AbstractExpressionSyntaxAST
{
    
    @Getter
    @Setter
    private AssignmentOperatorType assignmentOperatorType;
    
    
    @Getter
    @Setter
    private AbstractOperableSyntaxAST<?> leftSideOperable, rightSideOperable;
    
    
    public AssignmentExpressionSyntaxAST(final SyntaxAnalyzer syntaxAnalyzer) {
        super(syntaxAnalyzer, ASTType.ASSIGNMENT_EXPRESSION);
    }
    
    
    @Override
    public AbstractOperableSyntaxAST<?> parseAST(final AbstractSyntaxAST parentAST) {
        AbstractOperableSyntaxAST<?> leftSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_OR).parseAST(parentAST);
        if (leftSideAST == null)
            return null;
    
        final boolean isPeek2EqualSign = this.getSyntaxAnalyzer().matchesPeekToken(2, SymbolType.EQUAL) != null;
        if (isPeek2EqualSign && this.getSyntaxAnalyzer().matchesPeekToken(1, SymbolType.PLUS) != null) {
            this.getSyntaxAnalyzer().nextToken(3);
        
            final AbstractOperableSyntaxAST<?> rightSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_OR).parseAST(parentAST);
            if (rightSideAST == null)
                return null;
    
            this.assignmentOperatorType = AssignmentOperatorType.ADD_ASSIGN;
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd((this.rightSideOperable = rightSideAST).getEnd());
            leftSideAST = this;
        } else if (isPeek2EqualSign && this.getSyntaxAnalyzer().matchesPeekToken(1, SymbolType.MINUS) != null) {
            this.getSyntaxAnalyzer().nextToken(3);
        
            final AbstractOperableSyntaxAST<?> rightSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_OR).parseAST(parentAST);
            if (rightSideAST == null)
                return null;
    
            this.assignmentOperatorType = AssignmentOperatorType.SUB_ASSIGN;
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd((this.rightSideOperable = rightSideAST).getEnd());
            leftSideAST = this;
        } else if (isPeek2EqualSign && this.getSyntaxAnalyzer().matchesPeekToken(1, SymbolType.ASTERISK) != null) {
            this.getSyntaxAnalyzer().nextToken(3);
        
            final AbstractOperableSyntaxAST<?> rightSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_OR).parseAST(parentAST);
            if (rightSideAST == null)
                return null;
    
            this.assignmentOperatorType = AssignmentOperatorType.MUL_ASSIGN;
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd((this.rightSideOperable = rightSideAST).getEnd());
            leftSideAST = this;
        } else if (isPeek2EqualSign && this.getSyntaxAnalyzer().matchesPeekToken(1, SymbolType.SLASH) != null) {
            this.getSyntaxAnalyzer().nextToken(3);
        
            final AbstractOperableSyntaxAST<?> rightSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_OR).parseAST(parentAST);
            if (rightSideAST == null)
                return null;
    
            this.assignmentOperatorType = AssignmentOperatorType.DIV_ASSIGN;
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd((this.rightSideOperable = rightSideAST).getEnd());
            leftSideAST = this;
        } else if (isPeek2EqualSign && this.getSyntaxAnalyzer().matchesPeekToken(1, SymbolType.PERCENT) != null) {
            this.getSyntaxAnalyzer().nextToken(3);
        
            final AbstractOperableSyntaxAST<?> rightSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_OR).parseAST(parentAST);
            if (rightSideAST == null)
                return null;
    
            this.assignmentOperatorType = AssignmentOperatorType.MOD_ASSIGN;
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd((this.rightSideOperable = rightSideAST).getEnd());
            leftSideAST = this;
        } else if (this.getSyntaxAnalyzer().matchesPeekToken(1, SymbolType.EQUAL) != null) {
            this.getSyntaxAnalyzer().nextToken(2);
        
            final AbstractOperableSyntaxAST<?> rightSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_OR).parseAST(parentAST);
            if (rightSideAST == null)
                return null;
    
            this.assignmentOperatorType = AssignmentOperatorType.ASSIGN;
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd((this.rightSideOperable = rightSideAST).getEnd());
            leftSideAST = this;
        }
        return leftSideAST;
    }
    
    
    @Override
    public void printSyntaxAST(final PrintStream printStream, final String indents) {
        printStream.println(indents + "├── left:");
        printStream.println(indents + "│   └── " + this.getLeftSideOperable().getClass().getSimpleName());
        this.getLeftSideOperable().printSyntaxAST(printStream, indents + "│        ");
        printStream.println(indents + "├── operator: " + this.getAssignmentOperatorType());
        printStream.println(indents + "└── right:");
        printStream.println(indents + "    └── " + this.getRightSideOperable().getClass().getSimpleName());
        this.getRightSideOperable().printSyntaxAST(printStream, indents + "        ");
    }
    
}
