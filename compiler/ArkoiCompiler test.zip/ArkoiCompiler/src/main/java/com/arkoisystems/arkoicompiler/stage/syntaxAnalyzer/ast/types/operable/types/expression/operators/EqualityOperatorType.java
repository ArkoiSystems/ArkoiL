package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.operators;

public enum EqualityOperatorType
{
    
    EQUAL,
    NOT_EQUAL
    
}