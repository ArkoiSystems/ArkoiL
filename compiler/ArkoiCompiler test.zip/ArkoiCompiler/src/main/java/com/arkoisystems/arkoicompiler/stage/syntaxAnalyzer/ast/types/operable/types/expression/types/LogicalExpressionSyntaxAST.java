/*
 * Copyright © 2019-2020 ArkoiSystems (https://www.arkoisystems.com/) All Rights Reserved.
 * Created ArkoiCompiler on February 15, 2020
 * Author timo aka. єхcsє#5543
 */
package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.types;

import com.arkoisystems.arkoicompiler.stage.lexcialAnalyzer.token.utils.SymbolType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.SyntaxAnalyzer;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.AbstractSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.AbstractOperableSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.AbstractExpressionSyntaxAST;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.operators.LogicalOperatorType;
import com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.utils.ASTType;
import lombok.Getter;
import lombok.Setter;

import java.io.PrintStream;

public class LogicalExpressionSyntaxAST extends AbstractExpressionSyntaxAST
{
    
    @Getter
    private final LogicalOperatorType logicalOperatorType;
    
    
    @Getter
    @Setter
    private AbstractOperableSyntaxAST<?> leftSideOperable, rightSideOperable;
    
    
    public LogicalExpressionSyntaxAST(final SyntaxAnalyzer syntaxAnalyzer, final LogicalOperatorType logicalOperatorType) {
        super(syntaxAnalyzer, ASTType.LOGICAL_EXPRESSION);
        
        this.logicalOperatorType = logicalOperatorType;
    }
    
    
    @Override
    public AbstractOperableSyntaxAST<?> parseAST(final AbstractSyntaxAST parentAST) {
        if (this.getLogicalOperatorType() == LogicalOperatorType.LOGICAL_OR) {
            final AbstractOperableSyntaxAST<?> leftSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_AND).parseAST(this);
            if (leftSideAST == null)
                return null;
            
            return this.parseLogicalOr(leftSideAST);
        } else if (this.getLogicalOperatorType() == LogicalOperatorType.LOGICAL_AND) {
            final AbstractOperableSyntaxAST<?> leftSideAST = new EqualityExpressionSyntaxAST(this.getSyntaxAnalyzer()).parseAST(this);
            if (leftSideAST == null)
                return null;
            
            return this.parseLogicalAnd(leftSideAST);
        } else return null;
    }
    
    private AbstractOperableSyntaxAST<?> parseLogicalOr(AbstractOperableSyntaxAST<?> leftSideAST) {
        if (this.getSyntaxAnalyzer().matchesPeekToken(1, SymbolType.VERTICAL_BAR) != null
                && this.getSyntaxAnalyzer().matchesPeekToken(2, SymbolType.VERTICAL_BAR) != null) {
            this.getSyntaxAnalyzer().nextToken(2);
            
            final AbstractOperableSyntaxAST<?> rightSideAST = new LogicalExpressionSyntaxAST(this.getSyntaxAnalyzer(), LogicalOperatorType.LOGICAL_AND).parseAST(this);
            if (rightSideAST == null)
                return null;
            
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd((this.rightSideOperable = rightSideAST).getEnd());
            leftSideAST = this;
        }
        return leftSideAST;
    }
    
    
    private AbstractOperableSyntaxAST<?> parseLogicalAnd(AbstractOperableSyntaxAST<?> leftSideAST) {
        if (this.getSyntaxAnalyzer().matchesPeekToken(1, SymbolType.AMPERSAND) != null && this.getSyntaxAnalyzer().matchesPeekToken(2, SymbolType.AMPERSAND) != null) {
            this.getSyntaxAnalyzer().nextToken(2);
            
            final AbstractOperableSyntaxAST<?> rightSideAST = new EqualityExpressionSyntaxAST(this.getSyntaxAnalyzer()).parseAST(this);
            if (rightSideAST == null)
                return null;
    
            this.setStart((this.leftSideOperable = leftSideAST).getStart());
            this.setEnd((this.rightSideOperable = rightSideAST).getEnd());
            leftSideAST = this;
        }
        return leftSideAST;
    }
    
    
    @Override
    public void printSyntaxAST(final PrintStream printStream, final String indents) {
        printStream.println(indents + "├── left:");
        printStream.println(indents + "│   └── " + this.getLeftSideOperable().getClass().getSimpleName());
        this.getLeftSideOperable().printSyntaxAST(printStream, indents + "│       ");
        printStream.println(indents + "├── operator: " + this.getLogicalOperatorType());
        printStream.println(indents + "└── right:");
        printStream.println(indents + "    └── " + this.getRightSideOperable().getClass().getSimpleName());
        this.getRightSideOperable().printSyntaxAST(printStream, indents + "        ");
    }
    
}
