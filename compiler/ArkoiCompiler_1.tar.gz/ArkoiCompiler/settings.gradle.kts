rootProject.name = "ArkoiCompiler"

