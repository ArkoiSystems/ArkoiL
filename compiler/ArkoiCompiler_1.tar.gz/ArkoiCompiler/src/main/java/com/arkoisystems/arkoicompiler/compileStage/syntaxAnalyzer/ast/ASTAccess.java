package com.arkoisystems.arkoicompiler.compileStage.syntaxAnalyzer.ast;

public enum ASTAccess
{
    
    THIS_ACCESS,
    GLOBAL_ACCESS,
    
}