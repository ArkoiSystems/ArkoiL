package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.operators;

public enum LogicalOperatorType
{
    
    LOGICAL_AND,
    LOGICAL_OR
    
}