package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.types.utils;

public enum CastOperatorType
{
    
    BYTE,
    FLOAT,
    SHORT,
    DOUBLE,
    INTEGER
    
}