package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.types.utils;

public enum PostfixOperatorType
{
    
    POSTFIX_ADD,
    POSTFIX_SUB,
    
}