package com.arkoisystems.arkoicompiler.stage.syntaxAnalyzer.ast.types.operable.types.expression.types.utils;

public enum PrefixOperatorType
{
    
    PREFIX_ADD,
    PREFIX_SUB,
    NEGATE,
    AFFIRM
    
}